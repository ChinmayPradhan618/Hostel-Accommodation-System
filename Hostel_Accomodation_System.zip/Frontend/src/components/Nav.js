  import React from 'react'
  import './nav.css'
  export default function Nav() {
    return (
      <div><nav class="navbar">
      <div class="navbar-title">
        <h1 style={{textAlign:"center",color:"white",marginLeft:"35px"}}>
        HOSTEL MANAGEMENT SYSTEM</h1>
      </div>
    </nav>
    </div>
    )
  }
